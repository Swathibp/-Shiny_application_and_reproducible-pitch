# Assignment: Shiny Application and Reproducible Pitch

This project has two parts. First, this is a Shiny application, that also deploed on servers. Second, Rstudio Presenter to with a reproducible pitch presentation about application.

## Shiny Application
Folder [shiny-application](shiny-application) contais sources for Shiny Application.
Main idea of this application is to create Fake Contacts Generator that could help into some apllication testing.
URL to check application: [https://ishkurko.shinyapps.io/shiny-application/](https://Swathibp.shinyapps.io/shiny-application/)

## Reproducible Pitch
Folder [reproducible-pitch-presentation](reproducible-pitch-presentation) contais sources for Reproducible Pitch that describes Fake Contacts Generator application.
URL to check presentation: [http://rpubs.com/Swathibp/fake-contacts-generator-presentation](http://rpubs.com/Swathibp/fake-contacts-generator-presentation)